public class OuterClass {
    
    private int outerVariable = 10;
    
    public void outerMethod() {
        System.out.println("Inside outer method");
        InnerClass innerObject = new InnerClass();
        innerObject.innerMethod();
    }
    
    public class InnerClass {
        
        private int innerVariable = 20;
        
        public void innerMethod() {
            System.out.println("Inside inner method");
            System.out.println("Outer variable: " + outerVariable);
            System.out.println("Inner variable: " + innerVariable);
        }
    }
    
    public static void main(String[] args) {
        OuterClass outerObject = new OuterClass();
        outerObject.outerMethod();
    }
}

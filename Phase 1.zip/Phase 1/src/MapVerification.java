import java.util.HashMap;
import java.util.Map;

public class MapVerification {

    public static void main(String[] args) {

        // Create a new map
        Map<Integer, String> map = new HashMap<>();

        // Verify that the map is empty
        if (!map.isEmpty()) {
            System.out.println("Error: Map should be empty.");
        }

        // Add some entries to the map
        map.put(1, "apple");
        map.put(2, "banana");
        map.put(3, "cherry");

        // Verify that the size of the map is correct
        if (map.size() != 3) {
            System.out.println("Error: Map size should be 3.");
        }

        // Verify that the map contains the expected entries
        if (!map.containsKey(1) || !map.containsValue("apple")) {
            System.out.println("Error: Map should contain key 1 with value 'apple'.");
        }
        if (!map.containsKey(2) || !map.containsValue("banana")) {
            System.out.println("Error: Map should contain key 2 with value 'banana'.");
        }
        if (!map.containsKey(3) || !map.containsValue("cherry")) {
            System.out.println("Error: Map should contain key 3 with value 'cherry'.");
        }

        // Remove an entry from the map
        map.remove(2);

        // Verify that the size of the map is correct
        if (map.size() != 2) {
            System.out.println("Error: Map size should be 2.");
        }

        // Verify that the map contains the expected entries after removal
        if (map.containsKey(2) || map.containsValue("banana")) {
            System.out.println("Error: Map should not contain key 2 with value 'banana'.");
        }
    }
}

	public class ExampleClass {
    
    // public variable accessible to all
    public int publicVar = 10;
    
    // private variable accessible only within the class
    private int privateVar = 20;
    
    // protected variable accessible within the class and its subclasses
    protected int protectedVar = 30;
    
    // default (package-private) variable accessible within the same package
    int defaultVar = 40;
    
    // public method accessible to all
    public void publicMethod() {
        System.out.println("This is a public method.");
    }
    
    // private method accessible only within the class
    private void privateMethod() {
        System.out.println("This is a private method.");
    }
    
    // protected method accessible within the class and its subclasses
    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }
    
    // default (package-private) method accessible within the same package
    void defaultMethod() {
        System.out.println("This is a default method.");
    }
}

public class AccessModifiers {
    public static void main(String[] args) {
        
        ExampleClass example = new ExampleClass();
        
        // accessing public variable and method
        System.out.println("Public variable: " + example.publicVar);
        example.publicMethod();
        
        // accessing private variable and method (will not compile)
        // System.out.println("Private variable: " + example.privateVar);
        // example.privateMethod();
        
        // accessing protected variable and method (will not compile)
        // System.out.println("Protected variable: " + example.protectedVar);
        // example.protectedMethod();
        
        // accessing default variable and method (will not compile)
        // System.out.println("Default variable: " + example.defaultVar);
        // example.defaultMethod();
    }
}

public class ArrayVerification {
  public static void main(String[] args) {
    int[] myArray = {1, 2, 3, 4, 5}; // creates an integer array with 5 elements
    
    // print the contents of the array
    for (int i = 0; i < myArray.length; i++) {
      System.out.println("Element at index " + i + " is: " + myArray[i]);
    }
    
    // sum the elements in the array
    int sum = 0;
    for (int i = 0; i < myArray.length; i++) {
      sum += myArray[i];
    }
    System.out.println("The sum of the elements in the array is: " + sum);
    
    // find the maximum element in the array
    int max = myArray[0];
    for (int i = 1; i < myArray.length; i++) {
      if (myArray[i] > max) {
        max = myArray[i];
      }
    }
    System.out.println("The maximum element in the array is: " + max);
    
    // find the average of the elements in the array
    double average = (double)sum / myArray.length;
    System.out.println("The average of the elements in the array is: " + average);
    
    // update an element in the array
    myArray[2] = 10;
    System.out.println("The updated element at index 2 is: " + myArray[2]);
  }
}

import java.util.regex.*;

public class RegExVerification {
    public static void main(String[] args) {
        String pattern = "hello";
        String[] stringsToTest = {"hello", "Hello", "hell", "hellomyfriend", "goodbye"};

        Pattern p = Pattern.compile(pattern);

        for (String s : stringsToTest) {
            Matcher m = p.matcher(s);

            System.out.println("Input string: " + s);

            if (m.matches()) {
                System.out.println("  Match found!");
            } else {
                System.out.println("  No match found.");
            }
        }
    }
}

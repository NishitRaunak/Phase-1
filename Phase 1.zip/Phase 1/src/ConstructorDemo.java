public class ConstructorDemo {
    private int x;
    private int y;

    // Default constructor
    public ConstructorDemo() {
        this.x = 0;
        this.y = 0;
    }

    // Parameterized constructor
    public ConstructorDemo(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Copy constructor
    public ConstructorDemo(ConstructorDemo other) {
        this.x = other.x;
        this.y = other.y;
    }

    public void printValues() {
        System.out.println("x = " + x + ", y = " + y);
    }

    public static void main(String[] args) {
        ConstructorDemo obj1 = new ConstructorDemo();
        ConstructorDemo obj2 = new ConstructorDemo(10, 20);
        ConstructorDemo obj3 = new ConstructorDemo(obj2);

        obj1.printValues();
        obj2.printValues();
        obj3.printValues();
    }
}

public class MethodVerification {
    
    public static void main(String[] args) {
        
        // Create an instance of the class containing the method we want to verify
        MethodVerification obj = new MethodVerification();
        
        // Call the method using different parameter values
        obj.myMethod("Hello");
        obj.myMethod("Goodbye");
        
        // Call the method and assign its return value to a variable
        int result = obj.myMethod(10, 20);
        System.out.println("The result is: " + result);
    }
    
    // Method that takes a String parameter and prints it to the console
    public void myMethod(String message) {
        System.out.println(message);
    }
    
    // Method that takes two int parameters, adds them together, and returns the result
    public int myMethod(int num1, int num2) {
        return num1 + num2;
    }
}

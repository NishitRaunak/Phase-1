
public class TypeCastingExample {
	public static void main(String[] args) {

        // Implicit Type Casting
        int num1 = 10;
        double num2 = num1;
        System.out.println("Implicit Type Casting - int to double: " + num2);

        // Explicit Type Casting
        double num3 = 10.5;
        int num4 = (int) num3;
        System.out.println("Explicit Type Casting - double to int: " + num4);

    }
}

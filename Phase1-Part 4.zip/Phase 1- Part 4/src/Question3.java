import java.util.*;

public class Question3{

    public static int exponentialSearch(int[] arr, int target) {
        int size = arr.length;
        
        if (arr[0] == target) {
            return 0; // Element found at index 0
        }

        int bound = 1;
        while (bound < size && arr[bound] <= target) {
            bound *= 2;
        }

        int left = bound / 2;
        int right = Math.min(bound, size - 1);

        return binarySearch(arr, target, left, right);
    }

    public static int binarySearch(int[] arr, int target, int left, int right) {
        if (right >= left) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; // Element found at mid index
            }

            if (arr[mid] > target) {
                return binarySearch(arr, target, left, mid - 1);
            }

            return binarySearch(arr, target, mid + 1, right);
        }

        return -1; // Element not found
    }

    public static void main(String[] args) {
        int[] arr = {2, 5, 9, 12, 18, 21, 25, 28, 32, 35};
        int target = 21;

        int index = exponentialSearch(arr, target);

        if (index != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}

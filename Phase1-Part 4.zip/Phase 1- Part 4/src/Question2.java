public class Question2 {
    // Iterative binary search
    public static int binarySearchIterative(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            // Check if target is present at the middle
            if (arr[mid] == target) {
                return mid;
            }

            // If target is greater, ignore the left half
            if (arr[mid] < target) {
                left = mid + 1;
            }

            // If target is smaller, ignore the right half
            else {
                right = mid - 1;
            }
        }

        // Target is not present in the array
        return -1;
    }

    // Recursive binary search
    public static int binarySearchRecursive(int[] arr, int target, int left, int right) {
        if (right >= left) {
            int mid = left + (right - left) / 2;

            // If the target is present at the middle
            if (arr[mid] == target) {
                return mid;
            }

            // If the target is smaller than the middle element, search in the left half
            if (arr[mid] > target) {
                return binarySearchRecursive(arr, target, left, mid - 1);
            }

            // If the target is greater than the middle element, search in the right half
            return binarySearchRecursive(arr, target, mid + 1, right);
        }

        // Target is not present in the array
        return -1;
    }

    // Test the binary search algorithm
    public static void main(String[] args) {
        int[] arr = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
        int target = 12;

        int resultIterative = binarySearchIterative(arr, target);
        int resultRecursive = binarySearchRecursive(arr, target, 0, arr.length - 1);

        System.out.println("Iterative Binary Search:");
        if (resultIterative == -1) {
            System.out.println("Target element not found in the array.");
        } else {
            System.out.println("Target element found at index " + resultIterative);
        }

        System.out.println("\nRecursive Binary Search:");
        if (resultRecursive == -1) {
            System.out.println("Target element not found in the array.");
        } else {
            System.out.println("Target element found at index " + resultRecursive);
        }
    }
}

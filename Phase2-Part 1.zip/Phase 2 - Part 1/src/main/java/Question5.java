import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@WebFilter("/*")
public class Question5 implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code, if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Pre-processing logic before the request is passed to the next filter or servlet

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String requestURI = httpRequest.getRequestURI();
        System.out.println("Request URI: " + requestURI);

        // Pass the request down the filter chain
        chain.doFilter(request, response);

        // Post-processing logic after the servlet has processed the request and generated a response

        // You can perform additional operations on the response, if needed
    }

    @Override
    public void destroy() {
        // Clean-up code, if needed
    }
}

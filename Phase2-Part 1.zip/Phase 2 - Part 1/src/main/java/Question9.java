import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/sessionDemo")
public class Question9 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Create a new session or get the existing session
        HttpSession session = request.getSession();

        // Set session attributes
        session.setAttribute("username", "John");
        session.setAttribute("email", "john@example.com");

        response.setContentType("text/html");
        response.getWriter().println("<html><body>");

        // Retrieve session attributes
        String username = (String) session.getAttribute("username");
        String email = (String) session.getAttribute("email");

        // Display session attributes
        response.getWriter().println("Username: " + username + "<br>");
        response.getWriter().println("Email: " + email + "<br>");

        response.getWriter().println("</body></html>");
    }
}

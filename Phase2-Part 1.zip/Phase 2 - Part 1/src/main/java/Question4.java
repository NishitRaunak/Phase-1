import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Question4 extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the response content type
        response.setContentType("text/html");
        
        // Write the response message
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Hello, Servlet!</h2>");
        response.getWriter().println("</body></html>");
    }
}

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class Question10i extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the username and password from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate the username and password (you can replace this with your own validation logic)
        if (username.equals("admin") && password.equals("password")) {
            // Create a session and store the username as an attribute
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            // Redirect to the home page
            response.sendRedirect("home.jsp");
        } else {
            // Display an error message if the login fails
            out.println("Invalid username or password. Please try again.");
        }
        out.close();
    }
}


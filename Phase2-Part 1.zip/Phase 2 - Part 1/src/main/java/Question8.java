import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HiddenFormFieldServlet")
public class Question8 extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String SESSION_COUNT_KEY = "sessionCount";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve the session count from the hidden form field or initialize it to 0
        String sessionCountStr = request.getParameter(SESSION_COUNT_KEY);
        int sessionCount = 0;
        if (sessionCountStr != null) {
            sessionCount = Integer.parseInt(sessionCountStr);
        }

        // Increment the session count and update the hidden form field
        sessionCount++;
        String hiddenFormField = "<input type='hidden' name='" + SESSION_COUNT_KEY + "' value='" + sessionCount + "'>";

        // Display the session count and the form
        out.println("<html><head><title>Session Tracking with Hidden Form Field</title></head><body>");
        out.println("<h2>Session Count: " + sessionCount + "</h2>");
        out.println("<form action='HiddenFormFieldServlet' method='get'>");
        out.println(hiddenFormField);
        out.println("<input type='submit' value='Increment Session Count'>");
        out.println("</form></body></html>");

        out.close();
    }
}

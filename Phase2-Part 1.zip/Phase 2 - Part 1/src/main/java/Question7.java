import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Question7 extends HttpServlet {

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    HttpSession session = request.getSession(true);
    
    // Generate a unique session ID
    String sessionId = session.getId();
    
    // Set session attribute
    session.setAttribute("username", "JohnDoe");
    
    // Append session ID to the URL
    String urlWithSessionId = response.encodeURL("welcome");
    
    // Redirect to the modified URL
    response.sendRedirect(urlWithSessionId);
  }
  
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }
  
}

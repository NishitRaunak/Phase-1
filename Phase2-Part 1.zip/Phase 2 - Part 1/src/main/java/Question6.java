import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Question6 extends HttpServlet {

  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
      
    // Get the current session or create a new one if it doesn't exist
    HttpSession session = request.getSession(true);
    
    // Set the session attribute if it doesn't exist
    if (session.getAttribute("visitCount") == null) {
      session.setAttribute("visitCount", 1);
    }
    
    // Increment the visit count
    int visitCount = (int) session.getAttribute("visitCount");
    session.setAttribute("visitCount", visitCount + 1);
    
    // Set the response content type
    response.setContentType("text/html");
    
    // Create a PrintWriter to write the HTML response
    PrintWriter out = response.getWriter();
    
    // Write the HTML response
    out.println("<html><head><title>Session Tracking using Cookies</title></head><body>");
    out.println("<h2>Session Tracking using Cookies</h2>");
    
    // Get the session ID
    String sessionId = session.getId();
    out.println("<p>Session ID: " + sessionId + "</p>");
    
    // Get the visit count from the session attribute
    out.println("<p>Visit Count: " + session.getAttribute("visitCount") + "</p>");
    
    out.println("</body></html>");
  }
}

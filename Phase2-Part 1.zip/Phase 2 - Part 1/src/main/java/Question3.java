import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Question3")
public class Question3 extends GenericServlet {

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        // This method is called for every HTTP request to the servlet

        // Set the response content type
        response.setContentType("text/html");

        // Get the writer object to write the response
        PrintWriter out = response.getWriter();

        // Write the HTML response
        out.println("<html><body>");
        out.println("<h2>Hello, Generic Servlet!</h2>");
        out.println("</body></html>");

        // Close the writer
        out.close();
    }
}

import java.util.*;

public class Question2 {
    
    public static int findFourthSmallest(int[] nums) {
        if (nums.length < 4) {
            throw new IllegalArgumentException("Input list should have at least 4 elements.");
        }
        
        int left = 0;
        int right = nums.length - 1;
        
        while (left <= right) {
            int pivotIndex = partition(nums, left, right);
            
            if (pivotIndex == 3) {
                return nums[pivotIndex];
            } else if (pivotIndex < 3) {
                left = pivotIndex + 1;
            } else {
                right = pivotIndex - 1;
            }
        }
        
        throw new IllegalArgumentException("No 4th smallest element found.");
    }
    
    private static int partition(int[] nums, int left, int right) {
        int pivotIndex = left;
        int pivotValue = nums[right];
        
        for (int i = left; i < right; i++) {
            if (nums[i] < pivotValue) {
                swap(nums, i, pivotIndex);
                pivotIndex++;
            }
        }
        
        swap(nums, pivotIndex, right);
        return pivotIndex;
    }
    
    private static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
    
    public static void main(String[] args) {
        int[] nums = {9, 0, 2, 7, 1, 5, 3, 8, 6};
        
        int fourthSmallest = findFourthSmallest(nums);
        System.out.println("The 4th smallest element is: " + fourthSmallest);
    }
}

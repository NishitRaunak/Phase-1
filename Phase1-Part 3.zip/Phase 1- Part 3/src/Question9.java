import java.util.LinkedList;
import java.util.Queue;

public class Question9 {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();

        // Inserting elements into the queue
        queue.offer("Element 1");
        queue.offer("Element 2");
        queue.offer("Element 3");

        System.out.println("Initial queue: " + queue);

        // Removing elements from the queue
        String removedElement = queue.poll();
        System.out.println("Removed element: " + removedElement);

        System.out.println("Queue after removal: " + queue);
    }
}

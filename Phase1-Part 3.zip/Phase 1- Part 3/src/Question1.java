public class Question1 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Example array
        
        System.out.println("Original Array:");
        printArray(array);
        
        rotateRight(array, 5);
        
        System.out.println("\nArray after rotating right by 5 steps:");
        printArray(array);
    }
    
    // Method to right rotate the array by specified steps
    public static void rotateRight(int[] array, int steps) {
        int length = array.length;
        steps = steps % length; // Normalize the steps
        
        // Reverse the entire array
        reverseArray(array, 0, length - 1);
        
        // Reverse the first 'steps' elements
        reverseArray(array, 0, steps - 1);
        
        // Reverse the remaining elements
        reverseArray(array, steps, length - 1);
    }
    
    // Method to reverse the elements in the array within the specified range
    public static void reverseArray(int[] array, int start, int end) {
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            
            start++;
            end--;
        }
    }
    
    // Method to print the elements of the array
    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

class Node2 {
    int data;
    Node2 next;

    public Node2(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node2 head;

    public CircularLinkedList() {
        this.head = null;
    }

    public void insert(int data) {
        Node2 newNode = new Node2(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (data <= head.data) {
            newNode.next = head;
            head = newNode;
        } else {
            Node2 current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node2 current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
    }
}

public class Question6 {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList();

        circularList.insert(5);
        circularList.insert(10);
        circularList.insert(15);
        circularList.insert(20);
        circularList.insert(25);

        System.out.println("Original circular linked list:");
        circularList.display();

        circularList.insert(18);

        System.out.println("\n\nCircular linked list after inserting a new element:");
        circularList.display();
    }
}

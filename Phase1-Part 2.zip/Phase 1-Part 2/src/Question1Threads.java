public class Question1Threads extends Thread {
    
    public void run() {
        System.out.println("Thread is running.");
    }
    
    public static void main(String[] args) {
        Question1Threads thread = new Question1Threads();
        thread.start();
    }
}

public class Question6 {
  public static void main(String[] args) {
    try {
      // Attempt to divide by zero, which will throw an ArithmeticException
      int result = 10 / 0;
      System.out.println(result);
    } catch (ArithmeticException e) {
      // Catch the ArithmeticException and print an error message
      System.out.println("An error occurred: " + e.getMessage());
    } finally {
      // The finally block will always execute, regardless of whether an exception was thrown
      System.out.println("Done.");
    }
  }
}

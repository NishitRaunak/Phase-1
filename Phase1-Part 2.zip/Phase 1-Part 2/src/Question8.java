// Define a class for a Person
class Person {
  // Define private fields for name and age
  private String name;
  private int age;
  
  // Define a constructor to set the name and age
  public Person(String name, int age) {
    this.name = name;
    this.age = age;
  }
  
  // Define public getter methods for name and age
  public String getName() {
    return this.name;
  }
  
  public int getAge() {
    return this.age;
  }
}

// Define a subclass of Person for a Student
class Student extends Person {
  // Define a private field for major
  private String major;
  
  // Define a constructor to set the name, age, and major
  public Student(String name, int age, String major) {
    // Call the superclass constructor to set the name and age
    super(name, age);
    this.major = major;
  }
  
  // Define a public getter method for major
  public String getMajor() {
    return this.major;
  }
  
  // Override the toString method to include major
  @Override
  public String toString() {
    return "Student{name=" + getName() + ", age=" + getAge() + ", major=" + this.major + "}";
  }
}

// Define a main class to create and use objects
public class Question8 {
  public static void main(String[] args) {
    // Create a Person object
    Person person = new Person("Alice", 30);
    
    // Access the fields and methods of the Person object
    System.out.println("Person name: " + person.getName());
    System.out.println("Person age: " + person.getAge());
    
    // Create a Student object
    Student student = new Student("Bob", 20, "Computer Science");
    
    // Access the fields and methods of the Student object
    System.out.println("Student name: " + student.getName());
    System.out.println("Student age: " + student.getAge());
    System.out.println("Student major: " + student.getMajor());
    
    // Use polymorphism to assign a Student object to a Person reference
    Person person2 = student;
    
    // Access the fields and methods of the Student object using the Person reference
    System.out.println("Person name (from Student object): " + person2.getName());
    System.out.println("Person age (from Student object): " + person2.getAge());
    
    // Use abstraction to hide the implementation details of the toString method
    System.out.println("Student object: " + student.toString());
  }
}

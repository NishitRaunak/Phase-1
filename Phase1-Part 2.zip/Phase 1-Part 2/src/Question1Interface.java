public class Question1Interface implements Runnable {
    
    public void run() {
        System.out.println("Thread is running.");
    }
    
    public static void main(String[] args) {
        Question1Interface myRunnable = new Question1Interface();
        Thread thread = new Thread(myRunnable);
        thread.start();
    }
}

public class Question2 {
    public static void main(String[] args) {
        // Example using sleep() method
        System.out.println("Starting sleep demo...");
        try {
            Thread.sleep(5000); // sleep for 5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Sleep demo complete.");

        // Example using wait() method
        Object lock = new Object();
        System.out.println("Starting wait demo...");
        synchronized(lock) {
            try {
                lock.wait(5000); // wait for 5 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Wait demo complete.");
    }
}

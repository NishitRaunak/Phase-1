import java.util.Scanner;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class Question5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter a number: ");
            int num = sc.nextInt();
            if (num < 0) {
                throw new CustomException("Number cannot be negative!");
            }
            System.out.println("Number entered: " + num);
        } catch (CustomException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Exception caught: " + e);
        } finally {
            System.out.println("End of program.");
            sc.close();
        }
    }
}
